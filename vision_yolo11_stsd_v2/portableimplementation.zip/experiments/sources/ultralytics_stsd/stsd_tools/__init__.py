"""Opt-in training/inference helpers for the isolated YOLO11-STSD fork."""
from .training import TemporalPairDataset, STSDPairTrainer
from .transfer import load_baseline_weights, temporal_modules, set_video_mode
__all__ = ("TemporalPairDataset", "STSDPairTrainer", "load_baseline_weights", "temporal_modules", "set_video_mode")
