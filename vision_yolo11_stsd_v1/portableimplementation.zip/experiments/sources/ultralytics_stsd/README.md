# YOLO11-STSD

Isolated source fork of Ultralytics **8.3.253**, AGPL-3.0. The original installed
baseline package is unchanged. Source modifications are in `ultralytics/nn/modules`,
`ultralytics/nn/tasks.py`, and `ultralytics/cfg/models/11/yolo11n-stsd.yaml`.

Architecture: original YOLO11n backbone → three soft spatial attention modules →
original FPN/PAN → three dynamic scale fusion branches → three optional temporal
modules → original Detect. The nano, one-class model has 4,759,077 parameters.

## Run in the existing workspace

```powershell
experiments\.venv\Scripts\python.exe experiments\scripts\vision_yolo11_stsd.py check
experiments\.venv\Scripts\python.exe experiments\scripts\vision_yolo11_stsd.py probe --epochs 8 --probe-frames-per-sequence 16 --name probe_train_8ep --device 0
experiments\.venv\Scripts\python.exe experiments\scripts\vision_yolo11_stsd.py train --epochs 80 --batch 8 --device 0
experiments\.venv\Scripts\python.exe experiments\scripts\vision_yolo11_stsd.py video --device 0
```

`train` defaults to the existing dataset YAML and completed single-class baseline
checkpoint, with semantic layer remapping. It saves/reloads the mapped initial
checkpoint and verifies the actual trainer weights before optimization.

The optional `STSDPairTrainer` shuffles temporal pairs as units and keeps the
standard BCHW model input, Detect head, loss, optimizer and label format. Both
frames retain their own detection loss. No training memory crosses batches.
`batch` is the total number of images and must be even on each device. The first
version uses deterministic square letterboxing without mosaic or random geometry.
Ordinary training (`--spatial-only`) does not learn temporal fusion.

Supported frame naming: `<sequence>_<number>.jpg` or per-sequence folders containing
numbered frame names such as `000001.jpg`. Only images inside the current split
are paired. `temporal_max_frame_gap: 32` in data YAML controls allowable frame gaps.
Other conventions can use explicit same-sequence index tuples in
`TemporalPairDataset`. Video cache assumes stable lanes; reset on every new stream.

## Portable source archive

Extract `portableimplementation.zip` preserving its `experiments/` hierarchy.
Create a separate Python environment with PyTorch/torchvision compatible with your
CUDA installation, then install `ultralytics==8.3.253` for its dependencies. The
runner puts this fork first on `sys.path`; installing the fork over the baseline
environment is unnecessary. The archive includes source and tests, not weights,
datasets or a virtual environment.

For another dataset, supply actual paths:

```powershell
python experiments/scripts/vision_yolo11_stsd.py train --data path/to/drone.yaml --weights path/to/yolo11n.pt --epochs 80 --batch 8 --device 0
```

Convert Anti-UAV annotations to YOLO detection labels, retain video-disjoint splits,
and preserve chronological frame identifiers. Current engineering probes use the
DroneDetectionThesis RGB dataset, **not** the official Anti-UAV benchmark.

## Interpretation

Sky maps are detector-trained attention, not supervised sky segmentation.
Dynamic weights are per image and sum to one. Temporal fusion uses actual paired
training and an explicit detached video cache; image inference is stateless.
There is no motion alignment or optical flow in this version. ONNX/JIT tracing
uses the image path and does not export the Python video cache.

Eight module/integration checks passed. A short single-seed eight-epoch probe on
128 train/32 validation frames produced mAP50 0.4983 and mAP50–95 0.2908. The
completed baseline on that same validation subset was 0.9950 / 0.4047. This verifies
a working detector training path; **it does not demonstrate an improvement**.
Matched-budget experiments and module ablations are still needed.
